from setuptools import setup, find_packages

setup(
    name='kerpy',
    version='0.1.0',
    url='https://github.com/oxmlcs/kerpy',
    packages=find_packages(),
    description='Code for kernel methods',
    license='MIT'
)
